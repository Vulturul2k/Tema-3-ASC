#!/bin/bash

./tema3_opt_m ../input/input